package src;

public enum Sex {
    MALE,
    FEMALE
}